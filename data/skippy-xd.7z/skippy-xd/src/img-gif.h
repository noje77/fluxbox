#include "skippy.h"

pictw_t *
sgif_read(session_t *ps, const char *path);
