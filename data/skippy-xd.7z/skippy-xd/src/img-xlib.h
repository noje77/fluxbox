pictw_t *
simg_load_icon(session_t *ps, Window wid, int desired_size);
