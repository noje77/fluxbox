#include "skippy.h"

pictw_t *
sjpg_read(session_t *ps, const char *path);
