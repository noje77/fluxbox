#include "skippy.h"

void
spng_about(FILE *os);

pictw_t *
spng_read(session_t *ps, const char *path);
